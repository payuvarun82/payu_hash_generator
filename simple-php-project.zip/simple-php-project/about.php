<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Simple PHP Project</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📖 About Us</h1>
            <a href="index.php" class="back-link">← Back to Home</a>
        </header>
        <main>
            <section>
                <h2>🎯 Project Overview</h2>
                <p>This is a simple PHP web project designed to demonstrate basic PHP concepts and functionality.</p>
                <h3>🛠️ Technologies Used</h3>
                <ul>
                    <li><strong>PHP:</strong> Server-side scripting</li>
                    <li><strong>HTML5:</strong> Structure and content</li>
                    <li><strong>CSS3:</strong> Styling and layout</li>
                    <li><strong>JavaScript:</strong> Client-side interactivity</li>
                </ul>
                <h3>🚀 Getting Started</h3>
                <p>To run this project locally:</p>
                <ol>
                    <li>Make sure you have PHP installed (7.4 or higher)</li>
                    <li>Navigate to the project directory</li>
                    <li>Run: <code>php -S localhost:8000</code></li>
                    <li>Open your browser and go to <code>http://localhost:8000</code></li>
                </ol>
            </section>
        </main>
        <footer>
            <p>&copy; 2024 Simple PHP Project. Built with ❤️ and PHP.</p>
        </footer>
    </div>
</body>
</html>